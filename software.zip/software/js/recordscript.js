var selectedRow = null


function onFormSubmit() {
   
    if (validate()) {
      
        var formData = readFormData();
      
        if (selectedRow == null)
        {
       
            insertNewRecord(formData);
        }
        else
        {
          
            updateRecord(formData);
        }
    
        resetForm();
    }
}

function readFormData() {
    var formData = {};
  
    formData["stuName"] = document.getElementById("stuName").value;
    formData["stuID"] = document.getElementById("stuID").value;
    formData["course"] = document.getElementById("course").value;
    formData["grade"] = document.getElementById("grade").value;
    formData["attendance"] = document.getElementById("attendance").value;
  
    return formData;
}

function insertNewRecord(data) {
    var table = document.getElementById("stdlist").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);
    cell1 = newRow.insertCell(0);
    cell1.innerHTML = data.stuName;
    cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.stuID;
    cell3 = newRow.insertCell(2);
    cell3.innerHTML = data.course;
    cell4 = newRow.insertCell(3);
    cell4.innerHTML = data.grade;
    cell5 = newRow.insertCell(4);
    cell5.innerHTML = data.attendance;
    cell5 = newRow.insertCell(5);
    cell5.innerHTML = `<a onClick="onEdit(this)">Edit</a>
    <a onClick="onDelete(this)">Delete</a>`;
}

function resetForm() {
    document.getElementById("stuName").value = "";
    document.getElementById("stuID").value = "";
    document.getElementById("course").value = "";
    document.getElementById("grade").value = "";
    document.getElementById("age").value = "";
    selectedRow = null;
}

function onEdit(td) {
    selectedRow = td.parentElement.parentElement;
    document.getElementById("stuName").value = selectedRow.cells[0].innerHTML;
    document.getElementById("stuID").value = selectedRow.cells[1].innerHTML;
    document.getElementById("course").value = selectedRow.cells[2].innerHTML;
    document.getElementById("grade").value = selectedRow.cells[3].innerHTML;
    document.getElementById("attendance").value = selectedRow.cells[4].innerHTML;
}

function updateRecord(formData) {
    selectedRow.cells[0].innerHTML = formData.stuName;
    selectedRow.cells[1].innerHTML = formData.stuID;
    selectedRow.cells[2].innerHTML = formData.course;
    selectedRow.cells[3].innerHTML = formData.grade;
    selectedRow.cells[4].innerHTML = formData.attendance;
}

function onDelete(td) {
    if (confirm('Are you sure to delete this record ?')) {
        row = td.parentElement.parentElement;
        document.getElementById("stdlist").deleteRow(row.rowIndex);
        resetForm();
    }
}

function validate() {
    isValid = true;

    if (document.getElementById("stuName").value == "") {
        isValid = false;
        document.getElementById("stuNamevalidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("stuNamevalidationError").classList.contains("hide"))
        {
            document.getElementById("stuNamevalidationError").classList.add("hide");
        }
    }

    if (document.getElementById("stuID").value == "") {
        isValid = false;
        document.getElementById("stuIDvalidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("stuIDvalidationError").classList.contains("hide"))
        {
            document.getElementById("stuIDvalidationError").classList.add("hide");
        }
    }
 
    if (document.getElementById("course").value == "") {
        isValid = false;
        document.getElementById("coursevalidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("coursevalidationError").classList.contains("hide"))
        {
            document.getElementById("coursevalidationError").classList.add("hide");
        }
    }

    if (document.getElementById("grade").value == "") {
        isValid = false;
        document.getElementById("gradevalidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("gradevalidationError").classList.contains("hide"))
        {
            document.getElementById("gradevalidationError").classList.add("hide");
        }
    }

    if (document.getElementById("attendance").value == "") {
        isValid = false;
        document.getElementById("attendancevalidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("attendancevalidationError").classList.contains("hide"))
        {
            document.getElementById("attendancevalidationError").classList.add("hide");
        }
    }
    return isValid;
}